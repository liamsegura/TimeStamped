<img src="https://www.liamsegura.com/assets/images/timestamped.png">

# TimeStamped

Gone are the days of wasting precious seconds trying to figure out the current time and typing it out. With TimeStamped, you can now be blazingly fast and effortlessly add timestamps with just a simple hotkey. It's like having your own personal time-traveling assistant, without the complicated machinery or questionable time paradoxes.

[Visit site](https://timestamped.vercel.app/laptop.gif)
